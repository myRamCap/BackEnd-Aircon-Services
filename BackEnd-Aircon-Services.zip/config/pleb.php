<?php

/**
 * Putting this here to help remind you where this came from.
 *
 * I'll get back to improving this and adding more as time permits
 * if you need some help feel free to drop me a line.
 *
 * * Twenty-Years Experience
 * * PHP, JavaScript, Laravel, MySQL, Java, Python and so many more!
 *
 *
 * @author  Simple-Pleb <plebeian.tribune@protonmail.com>
 * @website https://www.simple-pleb.com
 * @source https://github.com/simplepleb/laravel-email-templates
 *
 * @license Free to do as you please
 *
 * @since 1.0
 *
 */

return [
    'app_name' => [
        'name'              => 'Car Services'
    ],

    'mail' => [
        // 'top_logo'          => 'https://www.simple-pleb.com/storage/uploads/logo/logo_big.svg',
        // 'welcome_url'       => 'https://www.simple-pleb.com/login',
        'street_address'    => 'Block 66 Lot 152 Phase 2 Cristo Rey Capas, Tarlac',
        'phone_number'      => '(+63) 970-764-0646',
        'info_email'        => 'myramcap@gmail.com',
        'play_url'          => '111',
        'ios_url'           => '123',

        // To remove from the email footer - make the value blank
        'facebook_url'      => 'https://www.facebook.com/profile.php?id=10009383362288',
        'youtube_url'       => 'https://www.youtube.com/@mangpogs',
        'linkedin_url'     => 'https://www.linkedin.com/in/ramcap-ph-25688324b',
        'tiktok_url'     => 'https://www.tiktok.com/@mangpogs',
    ],


];