<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Thanks for register with us!</h1>

    <p><?php echo e($get_user_name); ?></p>
    <p><?php echo e($validToken); ?></p>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Car-Services/resources/views/emails/welcome.blade.php ENDPATH**/ ?>