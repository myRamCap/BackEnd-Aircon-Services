<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('aircons', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('client_id');
            $table->string('aircon_name');
            $table->string('aircon_type')->nullable();
            // $table->string('contact_number')->nullable();
            $table->string('make')->nullable();
            $table->string('model')->nullable();
            $table->string('horse_power')->nullable();
            $table->string('serial_number', 255)->nullable();
            $table->longText('image')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('aircons');
    }
};
